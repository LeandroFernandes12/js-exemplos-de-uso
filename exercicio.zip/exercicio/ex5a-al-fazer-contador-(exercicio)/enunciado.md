# Exercício 5a: Contador de Cliques com Feedback Visual

## Enunciado:
Crie uma página que contenha um **botão** e um **parágrafo**. O botão deve **incrementar um contador de cliques** cada vez que for clicado. O valor do contador deve ser exibido no parágrafo. 

Além disso, a **cor de fundo** do parágrafo deve mudar:
- **Verde** quando o contador for **par**.
- **Vermelho** quando o contador for **ímpar**.
