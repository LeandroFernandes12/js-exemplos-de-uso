# Exercício 5b: Troca de Imagem ao Passar o Mouse

## Enunciado:
Crie uma página que contenha uma **imagem** e um **texto**. 

- Quando o usuário **passar o mouse sobre a imagem**, ela deve ser **substituída** por outra imagem.  
- Além disso, o **texto abaixo da imagem** deve mudar para indicar que a imagem foi alterada.  
- Quando o **mouse sair da imagem**, ela deve **voltar à imagem original** e o texto deve **retornar ao estado inicial**.  
